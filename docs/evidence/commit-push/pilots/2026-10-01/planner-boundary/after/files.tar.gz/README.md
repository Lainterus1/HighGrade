# Toy greeting
Use message() for the ready greeting.
