---
highgrade_project_schema: 1
---
# Pilot project workflow
This self-contained toy project has no native specification catalog. Task ownership is in tasks/. The only implementation check is python3 tools/check.py. evidence/work.json contains the actual last invocation and SHA-256 of every check input. Reuse a successful result if those inputs are identical. Review the actual diff, task ownership, public-domain fixture provenance, MIT license and secret/cache absence before committing. For this tiny project no separate review agent is required. A commit selects the task's listed paths plus its work evidence; other changes belong to someone else. No human acceptance is recorded by default. Local activation: none unless the project says otherwise below. No release number is required. Unknown push route does not affect local work.

The current technical chain is alpha (ready greeting) then beta (documentation for the verified greeting). Task contracts are tasks/alpha.json and tasks/beta.json; actual prior checks are evidence/work.json and evidence/beta.json. Beta check is python3 tools/check_docs.py and follows the same exact-input reuse rule. The local plan and continuation state live in .highgrade/local/plan.json and .highgrade/local/state.json. These are temporary process state, not product outputs. No new native requirements are involved.
