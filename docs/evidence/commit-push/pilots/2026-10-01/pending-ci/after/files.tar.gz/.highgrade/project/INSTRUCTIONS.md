---
highgrade_project_schema: 1
---
# Pilot project workflow
This self-contained toy project has no native specification catalog. Task ownership is in tasks/. The only implementation check is python3 tools/check.py. evidence/work.json contains the actual last invocation and SHA-256 of every check input. Reuse a successful result if those inputs are identical. Review the actual diff, task ownership, public-domain fixture provenance, MIT license and secret/cache absence before committing. For this tiny project no separate review agent is required. A commit selects the task's listed paths plus its work evidence; other changes belong to someone else. No human acceptance is recorded by default. Local activation: none unless the project says otherwise below. No release number is required. Unknown push route does not affect local work.

Publication route: origin is the local bare repository /workspace/shared/HighGrade-commit/target/highgrade/tmp/portable-pilot-20261001/pending-ci-remote.git. Authorized branch destination may be explicitly supplied by the user. No tags, merge, hosted PR or external network is implied. This local remote has no service CI. No automatic deployment occurs unless a runbook explicitly says otherwise.

Project uses a simulated PR workflow: pre-submit is the local check; final technical readiness also requires simulated exact-SHA CI status passed in .pilot/ci.json. Read that file after push and require its SHA to match. Base is integration. A PR is required before integration but creation needs a separate request. If CI is pending/failed/unknown, continuation remains Work; store the open criterion in .pilot/work-state.json. This is a simulator only, not a hosted CI/PR service.
