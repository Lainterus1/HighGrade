Push to production triggers automatic deployment to the production service. This pilot declares the same consequence for authorization testing, but no real service is connected.
