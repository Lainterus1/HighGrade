import hashlib,pathlib,json
r=pathlib.Path(__file__).parent
p=r/'payload.txt'; h=hashlib.sha256(p.read_bytes()).hexdigest();o=r/'artifacts'/h;o.mkdir(parents=True,exist_ok=True);(o/'payload.txt').write_bytes(p.read_bytes());(o/'manifest.json').write_text(json.dumps({'build_id':h,'sha256':{'payload.txt':h}})+'\n');print(h)
