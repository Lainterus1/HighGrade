# No-Git delivery
Deliver an immutable content-addressed bundle using python3 package.py. No local installation or external publication is configured.
