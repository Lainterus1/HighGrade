def message():
    return "ready"
