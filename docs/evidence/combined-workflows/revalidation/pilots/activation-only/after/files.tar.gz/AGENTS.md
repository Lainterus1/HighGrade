Read .highgrade/project/INSTRUCTIONS.md and README.md. Work only in this fixture.
