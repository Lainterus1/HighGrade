---
highgrade_project_schema: 1
---
# Pilot project workflow
This self-contained toy project has no native specification catalog. Task ownership is in tasks/. The only implementation check is python3 tools/check.py. evidence/work.json contains the actual last invocation and SHA-256 of every check input. Reuse a successful result if those inputs are identical. Review the actual diff, task ownership, public-domain fixture provenance, MIT license and secret/cache absence before committing. For this tiny project no separate review agent is required. A commit selects the task's listed paths plus its work evidence; other changes belong to someone else. No human acceptance is recorded by default. Local activation: none unless the project says otherwise below. No release number is required. Unknown push route does not affect local work.

Local activation is assigned after an authorized commit. Use python3 tools/activate.py preview SHA, then apply SHA, and status. It reads the committed app.py, never the working tree. Apply has no rollback guarantee; inspect status after any failure. No external systems or user profile are involved.
