import pathlib,json,sys,subprocess
r=pathlib.Path(__file__).resolve().parents[1];mode=sys.argv[1];revision=sys.argv[2] if len(sys.argv)>2 else None
state=r/'.pilot/active.json';old=json.loads(state.read_text())
if mode=='status': print(json.dumps(old));raise SystemExit(0)
body=subprocess.check_output(['git','show',revision+':app.py'],cwd=r,text=True)
record={'mode':mode,'revision':revision,'source':'git-show-exact-sha','content':body}
with (r/'.pilot/activation-calls.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
if mode=='preview':print(json.dumps(record));raise SystemExit(0)
if (r/'FAIL_ACTIVATION').exists():print('Injected fixture failure before switching active state',file=sys.stderr);raise SystemExit(23)
state.write_text(json.dumps({'revision':revision,'content':body})+'\n');print(state.read_text())
