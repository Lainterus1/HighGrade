# Toy greeting
Run python3 tools/check.py to validate the greeting.
