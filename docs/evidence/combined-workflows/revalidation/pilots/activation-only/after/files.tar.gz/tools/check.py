import pathlib,json,hashlib,datetime
r=pathlib.Path(__file__).resolve().parents[1]
inputs={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'app.py',r/'tools/check.py']}
ns={};exec((r/'app.py').read_text(),ns);ok=ns['message']()=='ready'
record={'command':'python3 tools/check.py','passed':ok,'inputs':inputs}
(r/'.pilot').mkdir(exist_ok=True)
with (r/'.pilot/test-calls.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
print(json.dumps(record));raise SystemExit(0 if ok else 1)
