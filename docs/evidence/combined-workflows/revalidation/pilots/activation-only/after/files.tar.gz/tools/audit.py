import sys,subprocess,json,pathlib,time
r=pathlib.Path(__file__).resolve().parents[1]
p=subprocess.run(sys.argv[1:],cwd=r,text=True,capture_output=True)
v={'argv':sys.argv[1:],'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
with (r/'.pilot/actions.jsonl').open('a') as f:f.write(json.dumps(v,ensure_ascii=False)+'\n')
print(p.stdout,end='');print(p.stderr,end='',file=sys.stderr);raise SystemExit(p.returncode)
