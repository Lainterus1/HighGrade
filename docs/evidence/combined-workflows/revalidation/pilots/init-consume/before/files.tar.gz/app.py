def message():
    return "starting"
