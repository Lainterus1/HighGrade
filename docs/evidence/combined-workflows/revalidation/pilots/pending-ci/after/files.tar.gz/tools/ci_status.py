import sys,json,pathlib
r=pathlib.Path(__file__).resolve().parents[1];p=r/".pilot/ci.json";v=json.loads(p.read_text());v["sha"]=sys.argv[1];p.write_text(json.dumps(v)+"\n");print(json.dumps(v))
